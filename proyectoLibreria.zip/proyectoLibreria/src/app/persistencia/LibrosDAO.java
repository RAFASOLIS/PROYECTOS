package app.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;








import org.apache.derby.client.am.Statement;

import app.Exception.LibroNoEncontradoException;
import app.modelo.Libro;

// Para crear la persistencia de esta aplicaci�n se ha usado el gestor de bbdd Derby Embedido
// Los fichero de la bbdd por tal efecto, est�n incluidos dentro de la aplicaci�n.
// Se ha implementado la Inteface ItfzLibrosDAO que nos facilita la plantilla de m�todo a seguir
public class LibrosDAO implements ItfzLibrosDAO{
private Connection con=null;
private final String driver="org.apache.derby.jdbc.EmbeddedDriver";
private final String url="jdbc:derby:LIBRERIA;create=true;";
private String usu;
private String pass;
private PreparedStatement s;
private String sql;

//Al constructor le debemos pasar el usuario y ocntrase�a para se pueda tener acceso a la bbdd
	public LibrosDAO(String usuario,String password){
		usu=usuario;
		pass=password;
		try{
		conexion();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
//M�todo que reliza la conexi�n a la bbdd
	public void conexion(){	
		try{
		Class.forName(driver).newInstance();
		con=DriverManager.getConnection(url,usu,pass);
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
	}
	// M�todo que realiza una consulta de inserci�n de datos en la tabla LIBROS de la bbdd LIBRERIA
	@Override
	public boolean altaLibro(Libro libro) {
		
		try{
			
			sql="INSERT INTO LIBROS VALUES ("+
			getNextId()+ ",'"+
			libro.getTitulo()+"','"+
			libro.getAutor()+"','"+
			libro.getEditorial()+"','"+
			libro.getIsbn()+"',"+
			libro.getPublicacion()+","+
			libro.getPrecio()+",'"+
			libro.getDescripcion()+"')";
			con.createStatement().execute(sql);
			return true; //retorna true si se ha dado de alta el libro
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return false;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}
		
	}
// M�todo que ejecuta una consulta de eliminaci�n sobre la tabla LIBRO de la BBDD LIBRERIA
	@Override
	public boolean eliminarLibro(int id)  {
		try{
			
		sql="DELETE  FROM LIBROS WHERE ID="+id;
		con.prepareStatement(sql).execute();
			return true;// retorna true en caso que la eliminaci�n se haya podido efectuar
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return false;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}
	}
// M�todo que ejecuta una consulta de eliminaci�n de todos los datos de la tabla LIBROS de la bbdd LIBRERIA
	
	public boolean eliminarTodo() {
		try{
		
		sql="DELETE  FROM LIBROS";
		 con.createStatement().execute(sql);
		
			return true;
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return false;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}
	}
	//M�todo que ejecuta una consulta de selecci�n con filtro por ISBN en la tabla LIBROS de la bbdd LIBRERIA
	@Override
	public List<Libro> consultarISBN(String isbn)throws LibroNoEncontradoException {

		sql="SELECT *FROM LIBROS WHERE ISBN='"+isbn +"'";
		List<Libro> lib=new ArrayList<Libro>();
		
		try{
			
			s=con.prepareStatement(sql);
			ResultSet r=s.executeQuery();
			while(r.next())
			{
				Libro lb=new Libro();
				lb.setId(r.getInt("ID"));
				lb.setTitulo(r.getString("TITULO"));
				lb.setAutor(r.getString("AUTOR"));
				lb.setEditorial(r.getString("EDITORIAL"));
				lb.setIsbn(r.getString("ISBN"));
				lb.setPublicacion(r.getInt("PUBLICACION"));
				lb.setPrecio(r.getDouble("PRECIO"));
				lb.setDescripcion(r.getString("DESCRIPCION"));
				lib.add(lb);	
			}
			if(lib.size()==0){
			 throw new LibroNoEncontradoException();	 
			}
			else{
				return lib;
				}
			
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return null;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return null;
		}			
	}
	//M�todo que ejecuta una consulta de selecci�n con filtro por TITULO en la tabla LIBROS de la bbdd LIBRERIA
	@Override
	public List<Libro> consultarTitulo(String titulo)throws LibroNoEncontradoException {
		sql="SELECT *FROM LIBROS WHERE TITULO='"+titulo +"'";
		List<Libro> lib=new ArrayList<Libro>();
try{
			
			s=con.prepareStatement(sql);
			ResultSet r=s.executeQuery();
			while(r.next())
			{
				Libro lb=new Libro();
				lb.setId(r.getInt("ID"));
				lb.setTitulo(r.getString("TITULO"));
				lb.setAutor(r.getString("AUTOR"));
				lb.setEditorial(r.getString("EDITORIAL"));
				lb.setIsbn(r.getString("ISBN"));
				lb.setPublicacion(r.getInt("PUBLICACION"));
				lb.setPrecio(r.getDouble("PRECIO"));
				lb.setDescripcion(r.getString("DESCRIPCION"));
				lib.add(lb);	
			}
			if(lib.size()==0){
			 throw new LibroNoEncontradoException();	 
			}
			else{
				return lib;
				}
			
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return null;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return null;
		}
	}
	//M�todo que ejecuta una consulta de selecci�n con filtro por TITULO en la tabla LIBROS de la bbdd LIBRERIA
	public List<Libro> listarTodo() throws LibroNoEncontradoException{
		sql="SELECT *FROM LIBROS";
		List<Libro> lib=new ArrayList<Libro>();
try{
			
			s=con.prepareStatement(sql);
			ResultSet r=s.executeQuery();
			while(r.next())
			{
				Libro lb=new Libro();
				lb.setId(r.getInt("ID"));
				lb.setTitulo(r.getString("TITULO"));
				lb.setAutor(r.getString("AUTOR"));
				lb.setEditorial(r.getString("EDITORIAL"));
				lb.setIsbn(r.getString("ISBN"));
				lb.setPublicacion(r.getInt("PUBLICACION"));
				lb.setPrecio(r.getDouble("PRECIO"));
				lb.setDescripcion(r.getString("DESCRIPCION"));
				lib.add(lb);	
			}
			if(lib.size()==0){
			 throw new LibroNoEncontradoException();	 
			}
			else{
				return lib;
				}
			
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return null;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return null;
		}
	}
	// M�todo que ejecuta una consulta de actualizaci�n en la tabla LIBROS de la BBDD LIBRERIA
	@Override
	public boolean modificarPrecio(String isbn, double precio) {
	
		
		try{
			
		sql="UPDATE LIBROS SET PRECIO="+ precio +"WHERE ISBN='"+isbn +"'";
		con.createStatement().execute(sql);
			return true;
		}catch(SQLException sqle){
			System.out.println(sqle.getMessage());
			return false;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}
	}
// M�todo que nos permite, a trav�s de una consulta a la bbdd, introducir autom�ticamente el pr�imo ID
public int getNextId()
{
	sql="SELECT COUNT(*) AS T FROM LIBROS";
	int rdo=0;

	try{
		
		s=con.prepareStatement(sql);
		ResultSet r=s.executeQuery();
		while(r.next()){
			rdo=r.getInt("T")+1;
		}
		return rdo +1;
	}catch(SQLException sqle){
		System.out.println(sqle.getMessage());
		return -1;
	}catch(Exception e){
		System.out.println(e.getMessage());
		return -1;
	}
}

}

