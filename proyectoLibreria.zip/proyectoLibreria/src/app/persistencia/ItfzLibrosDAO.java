package app.persistencia;

import java.sql.SQLException;
import java.util.List;

import app.Exception.LibroNoEncontradoException;
import app.modelo.Libro;

public interface ItfzLibrosDAO {

	public boolean altaLibro(Libro libro);
	public boolean eliminarLibro(int id) throws SQLException;
	public List<Libro> consultarISBN(String isbn)throws LibroNoEncontradoException;
	public List<Libro> consultarTitulo(String titulo)throws LibroNoEncontradoException;
	public boolean modificarPrecio(String isbn,double precio);
}
