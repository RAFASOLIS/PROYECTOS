package app.negocio;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import org.apache.derby.client.am.SqlException;

import app.Exception.LibroNoEncontradoException;
import app.cliente.Ventana;
import app.modelo.Libro;
import app.persistencia.LibrosDAO;

public class GestionLibreria implements ItfzGestionLibreria{

	LibrosDAO ldao=null;
	Ventana v=null;
	List<Libro> libros=new ArrayList<Libro>();
	//El constructor nos permite crear una ventana (Clase Ventana) de acceso a la aplicaci�n
	//Se crea una Ventana con un panel que nos permite el acceso, en caso de introducir los datos correctamente
	// podemos entrar en la interfaz de la aplicaci�n
	public GestionLibreria(Ventana v){
		
		this.v=v;
	}
		public void conectar(String usuario,String password){
			try
			{
				
				ldao=new LibrosDAO(usuario,password);
				ldao.conexion();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
		
	// M�todo que permite dar de alta un libro, usando la clase LibroDAO
	@Override
	public boolean altaLibro(Libro libro) {
		if(ldao.altaLibro(libro)){
			
			return true;
		}else{
			return false;
		}
		
	}
	// M�todo que permite eliminar  un libro, usando la clase LibroDAO
	@Override
	public boolean eliminarLibro(int id) {
	
		if(ldao.eliminarLibro(id)){
			return true;
		}else{
		
			return false;
		}
		
	}
	// M�todo que permite listar un libro con un determinado ISBN, usando la clase LibroDAO
	// El m�todo emplea la Excepci�n creada que se lanza en caso de no encontrarse el libro 
	@Override
	public List<Libro> consultarISBN(String isbn) {
		try{
		return ldao.consultarISBN(isbn);
		}catch(LibroNoEncontradoException ln){// usamos las Excepci�n creada 
			ln.getMessage();
			return null;
		}
	}
	// M�todo que permite listar un libro con un determinado ISBN, usando la clase LibroDAO
	// El m�todo emplea la Excepci�n creada que se lanza en caso de no encontrarse el libro 
	@Override
	public List<Libro> consultarTitulo(String titulo) {
		try{
			return ldao.consultarTitulo(titulo);		
		}catch(LibroNoEncontradoException ln){// usamos las Excepci�n creada 
			ln.getMessage();
			return null;
		}
		
}
	// M�todo que permite listar todos los libros, usando la clase LibroDAO
	// El m�todo emplea la Excepci�n creada que se lanza en caso de no encontrarse el libro
	public List<Libro> listarTodo() {
		try{
			
			return ldao.listarTodo();
		}catch(LibroNoEncontradoException ln){// usamos las Excepci�n creada 
			ln.getMessage();
			return null;
		}
		
	}

	// M�todo que modificar el preciode un libro seg�n su ISBN, usando la clase LibroDAO
		// El m�todo emplea la Excepci�n creada que se lanza en caso de no encontrarse el libro
	@Override
	public boolean modificarPrecio(String isbn, double precio) {
		ldao.modificarPrecio(isbn, precio);
		return false;
	}
	//M�todo que nos permite eliminar todos los registros, usando la clase LibrosDAO
public boolean eliminarTodo(){
	
		if(ldao.eliminarTodo()){
			return true;
		}else{
			return false;
		}
		
	
}
	
}
