package app.modelo;

import javax.swing.JDialog;
import javax.swing.JLabel;

public class Libro {

	private int id;
	private String titulo;
	private String autor;
	private String editorial;
	private String isbn;
	private int publicacion;
	private double precio;
	private String descripcion;
	private Object[] datos;
	
	
	
	public Libro(){
		
	}
	public Libro(String titulo,String autor,String editorial,String isbn,int publicacion,double precio,String descripcion){
		this.titulo=titulo;
		this.autor=autor;
		this.editorial=editorial;
		this.isbn=isbn;
		this.publicacion=publicacion;
		this.precio=precio;
		this.descripcion=descripcion;
	}
	public Libro(String titulo)
	{
		
		this.titulo=titulo;
	}
	
	// Geters
	
	public int getId(){ return id;}
	public String getTitulo(){return titulo;}
	public String getAutor(){return autor;}
	public String getEditorial(){return editorial;}
	public String getIsbn(){return isbn;}
	public int getPublicacion(){return publicacion;}
	public double getPrecio(){return precio;}
	public String getDescripcion(){return descripcion;}
	
	//Seters
	public void setId(int id){this.id=id;}
	public void setTitulo(String titulo){this.titulo=titulo;}
	public void setAutor(String autor){this.autor=autor;}
	public void setEditorial(String editorial){this.editorial=editorial;}
	public void setIsbn(String isbn){this.isbn=isbn;}
	public void setPublicacion(int publicacion){this.publicacion=publicacion;}
	public void setPrecio(double precio){this.precio=precio;}
	public void setDescripcion(String descripcion){this.descripcion=descripcion;}
	
	public String getString()
	{
		return "ID: "+ id +"-TITULO: " + titulo+ "-AUTOR: " +
	autor + "-EDITORIAL: " + editorial + "-ISBN: " + isbn  + "-PUBLICACION: "
				+ publicacion +  "-PRECIO: " + 
	precio+  "-DESCRIPCION: " + descripcion;
	}
	public Libro getLibro(){
	
		return this;
	}
	
}

