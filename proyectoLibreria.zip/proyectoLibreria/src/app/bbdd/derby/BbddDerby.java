package app.bbdd.derby;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//clase que crea la bbdd embedida derby
public class BbddDerby {

	
	private static Connection con=null;
	
	public  BbddDerby(){
		
	
	}
	//procedimiento que crea la bbdd LIBRERIA embedida en el proyecto
	public void crearBbddLibreria() throws SQLException
	{

		String url="jdbc:derby:LIBRERIA;create=true;user=rafael;password=curso";
		con=DriverManager.getConnection(url);
	}
	//procedimiento que crea la tabla LIBROS en la bbdd LIBRERIA
	public void  crearTablaLibros() throws SQLException{
		String sql;
		sql="CREATE TABLE LIBROS("+
		"ID INTEGER PRIMARY KEY,"+
		"TITULO VARCHAR(50), "+
		"AUTOR VARCHAR(50),"+
		"EDITORIAL VARCHAR(50),"+
		"ISBN VARCHAR(20),"+
		"PUBLICACION INTEGER,"+
		"PRECIO DOUBLE,"+
		"DESCRIPCION VARCHAR(200))";
	con.createStatement().execute(sql);
				
	}
	
}
