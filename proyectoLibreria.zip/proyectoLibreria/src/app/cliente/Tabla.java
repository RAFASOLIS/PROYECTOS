package app.cliente;

import java.awt.Dimension;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import app.modelo.Libro;
//Esta clase nor permite crear una Tabla para introducir los datos de las consultas a la BBDD
// Permite transformar el objeto List<Libro> pasado como argumento en un objeto Objet[][] necesario
// para crear el JTable
public class Tabla extends JTable{

private JTable t;
private DefaultTableModel dtm;
private JScrollPane sp;
private Dimension dim =new Dimension(50,70);
private Object[] cabeceras={"ID","TITULO","AUTOR","EDITORIAL","ISBN","PUBLICACION","PRECIO","DESCRIPCION"};
	public Tabla(List<Libro> libros){
		
	
		DefaultTableModel dtm=new DefaultTableModel();
		dtm.setColumnIdentifiers(cabeceras);
		for(int fil=0;fil<libros.size();fil++)
		{
			Object[] dat=new Object[8];
			
			dat[0]=libros.listIterator(fil).next().getId();
			dat[1]=libros.listIterator(fil).next().getTitulo();
			dat[2]=libros.listIterator(fil).next().getAutor();
			dat[3]=libros.listIterator(fil).next().getEditorial();
			dat[4]=libros.listIterator(fil).next().getIsbn();
			dat[5]=libros.listIterator(fil).next().getPublicacion();
			dat[6]=libros.listIterator(fil).next().getPrecio();
			dat[7]=libros.listIterator(fil).next().getDescripcion();
		dtm.addRow(dat);
	}
		
	
		
		t=new JTable(dtm);
		t.setPreferredScrollableViewportSize(dim);

		sp=new JScrollPane(t);
		
		
	}

	//Este m�todo devuelve el JScrollPane
public JScrollPane getTabla(){
	return sp;
}


}
