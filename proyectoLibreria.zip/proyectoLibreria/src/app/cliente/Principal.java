package app.cliente;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.UIManager;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.BusinessBlueSteelSkin;

import app.bbdd.derby.BbddDerby;
import app.modelo.Libro;
import app.negocio.GestionLibreria;
//import app.bbdd.derby.BbddDerby;
import app.persistencia.LibrosDAO;

public class Principal {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

// * Este c�digo se ha usado �nicamente para crear la bbdd LIBRERIA 
 //* a trav�s de la Clase BbddDerby
	/*try{
		BbddDerby bbdd=new BbddDerby();
		bbdd.crearBbddLibreria();
		bbdd.crearTablaLibros();
		}
	catch(Exception e){
		e.printStackTrace();
		}*/
	estilo();
	Ventana v=new Ventana();
	v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	v.setVisible(true);
		
		
	}
	
	public static void estilo(){
		try{ 
			SubstanceLookAndFeel.setSkin (new BusinessBlueSteelSkin ());
			
			}catch (Exception e){e.printStackTrace();} 
	}
	
	
		
}
