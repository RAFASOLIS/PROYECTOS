package app.cliente;

	
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;














import app.modelo.Libro;
import app.negocio.GestionLibreria;
import app.persistencia.LibrosDAO;

	public class Ventana  extends JFrame implements ActionListener{


		private JLabel lUsu;
		private JLabel lPass;
		private JTextField tfUsu;
		private JTextField tfPass;
		private JPanel pAcces;
		private JLabel lMsg;
		private JButton btEntrar;
		
		
		private JTextField tfId;
		private JTextField tfTitulo;
		private JTextField tfAutor;
		private JTextField tfEditorial;
		private JTextField tfIsbn;
		private JTextField tfPublicacion;
		private JTextField tfPrecio;
		private JTextField tfDescripcion;
		
		
		private JLabel lId;
		private JLabel lTitulo;
		private JLabel lAutor;
		private JLabel lEditorial;
		private JLabel lIsbn;
		private JLabel lPublicacion;
		private JLabel lPrecio;
		private JLabel lDescripcion;
		
		private JToolBar tb;
		private JButton btAlta;
		private JButton btEliminar;
		private JButton btConsultarIsbn;
		private JButton btConsultarTitulo;
		private JButton btListar;
		private JButton btModificarPrecio;
		
	    private Libro l;
		private  String titulo,editorial,autor,isbn,descripcion;
		private int publicacion;
		private double precio;
		private List<Libro> libros;
		private GestionLibreria gl;
		
		private JOptionPane op;
		
		
		private JPanel p;
		
		private JMenuBar jmb;
		
		public Ventana(){
			
			this.setTitle("GESTI�N DE LIBRER�A");
			this.setBounds(0,0,1020,1000);
			gl=new GestionLibreria(this);
			
			dise�o();
			acceso();
			
		}
		//Este m�todo crea un Panel inicial que impide acceder a la aplicaci�n en caso de no 
		// introducir el usuario y contrase�a correctos
		public void acceso(){
			pAcces=new JPanel();
			pAcces.setLayout(null);
			pAcces.setBounds(0,50,1000,800);
			lUsu=new JLabel("Usuario:");
			lPass=new JLabel("Contrase�a:");
			lUsu.setBounds(10,50,100,30);
			lPass.setBounds(10,100,100,30);
			tfUsu=new JTextField();
			tfPass=new JTextField();
			tfUsu.setBounds(150,50,100,30);
			tfPass.setBounds(150,100,100,30);
			lMsg=new JLabel("Introduzca usuario y contrase�a para acceder a la aplicaci�n");
			lMsg.setBounds(10,10,400,30);
			pAcces.add(lMsg);
			pAcces.add(lUsu);
			pAcces.add(lPass);
			pAcces.add(tfUsu);
			pAcces.add(tfPass);
			
			btEntrar=new JButton("Entrar");
			btEntrar.setBounds(10,150,100,30);
			pAcces.add(btEntrar);
			this.add(pAcces);
			btEntrar.addActionListener(new ActionListener(){
				//m�todo interno que controla el evento del bot�n "Entrar"
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					if(tfUsu.getText().equals("Rafael") && tfPass.getText().equals("curso")){
						
						gl.conectar(tfUsu.getText(), tfPass.getText());
						pAcces.setVisible(false);
						p.setVisible(true);
						}else{
							lMsg.setText("Acceso denegado: usuario y/o contrase�a no v�lidos");
						}
				}
				
			});
			
				
			
			
		}
		//M�todo que permite dise�ar la interfaz de la aplicaci�n "GESTI�N DE LIBRER�A"
		public void dise�o(){
			
		
			
			//instancias
			tfId =new JTextField();
			tfTitulo=new JTextField();
			tfAutor=new JTextField();
			tfEditorial=new JTextField();
			tfIsbn=new JTextField();
			tfPublicacion=new JTextField();
			tfPrecio=new JTextField();
			tfDescripcion=new JTextField();
			
			lId=new JLabel("Id");
			lTitulo=new JLabel("Titulo: ");
			lAutor=new JLabel("Autor: ");
			lEditorial=new JLabel("Editorial: ");
			lIsbn=new JLabel("Isbn: ");
			lPublicacion=new JLabel("Publicacion: ");
			lPrecio=new JLabel("Precio: ");
			lDescripcion=new JLabel("Descripcion: ");
			
			
			tb=new JToolBar();
			btAlta = new JButton("ALTA");
			btEliminar=new JButton("ELIMINAR");
			btConsultarIsbn=new JButton("CONSULTAR ISBN");
			btConsultarTitulo=new JButton("CONSULTAR TITULO");
			btListar=new JButton("LISTAR");
			btModificarPrecio=new JButton("MODIFICAR PRECIO");
			p=new JPanel();
		
			libros= new ArrayList<Libro>();
			
		
	
			
			//dimensionamiento de objetos
			lId.setBounds(10,50,150,40);
			lTitulo.setBounds(10,100,150,40);
			lAutor.setBounds(10,150,150,40);
			lEditorial.setBounds(10,200,150,40);
			lIsbn.setBounds(10,250,150,40);
			lPublicacion.setBounds(10,300,150,40);
			lPrecio.setBounds(10,350,150,40);
			lDescripcion.setBounds(10,400,150,40);
			
			tfId.setBounds(200,50,150,40);
			tfTitulo.setBounds(200,100,150,40);
			tfAutor.setBounds(200,150,150,40);
			tfEditorial.setBounds(200,200,150,40);
			tfIsbn.setBounds(200,250,150,40);
			tfPublicacion.setBounds(200,300,150,40);
			tfPrecio.setBounds(200,350,150,40);
			tfDescripcion.setBounds(200,400,150,40);
			
		
			tb.setBounds(0,0,1000,30);
			
			
			btAlta.setBounds(0,0,100,100);
			btEliminar.setBounds(200,0,100,50);
			btConsultarIsbn.setBounds(300,0,100,50);
			btConsultarTitulo.setBounds(400,0,100,50);
			btListar.setBounds(500,0,100,50);
			btModificarPrecio.setBounds(600,0,100,50);
			
			//a�adir los escuchadores de eventos
			btAlta.addActionListener((ActionListener) this);
			btEliminar.addActionListener((ActionListener) this);
			btConsultarIsbn.addActionListener((ActionListener) this);
			btConsultarTitulo.addActionListener((ActionListener)this);
			btListar.addActionListener((ActionListener) this);
			btModificarPrecio.addActionListener((ActionListener) this);
			
		
			
			//adhesi�n
			
			tb.add(btAlta);
			tb.add(btEliminar);
			tb.add(btConsultarIsbn);
			tb.add(btConsultarTitulo);
			tb.add(btListar);
			tb.add(btModificarPrecio);
			p.add(tb);
			
			p.add(tfId);
			p.add(tfTitulo);
			p.add(tfAutor);
			p.add(tfEditorial);
			p.add(tfIsbn);
			p.add(tfPublicacion);
			p.add(tfPrecio);
			p.add(tfDescripcion);
			
			p.add(lId);
			p.add(lTitulo);
			p.add(lAutor);
			p.add(lEditorial);
			p.add(lIsbn);
			p.add(lPublicacion);
			p.add(lPrecio);
			p.add(lDescripcion);
			
			
			
		
		
			p.setLayout(null);
			p.setBounds(0,0,1000,1000);
			this.getContentPane().add(p);
			p.setVisible(false);
			
			
			
		}
	
	//Este m�todo convierte los valores contenidos en los campos de texto a los tipos de los atributos
	// correspondientes de la clase Libro
			public void conversionDatos(){
				try{
				titulo=tfTitulo.getText();
				autor=tfAutor.getText();
				editorial=tfEditorial.getText();
				isbn=tfIsbn.getText();
				publicacion=Integer.valueOf(tfPublicacion.getText());
				precio=Double.valueOf(tfPrecio.getText());
				descripcion=tfDescripcion.getText();
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			
			
			
			//A trav�s de este m�todo capturamos los diferentes eventos originados al pulsar los diferentes botones
			public void actionPerformed(ActionEvent e){
				
				if(e.getSource().equals(btAlta)){
						if(tfTitulo.getText().equals(""))
						{
							op.showMessageDialog(p,"Campo TITULO obligatorio","INFORMACI�N",JOptionPane.INFORMATION_MESSAGE);
						}else{
							
							conversionDatos();
							Libro l=new Libro(titulo,autor,editorial,isbn,publicacion,precio,descripcion);
							gl.altaLibro(l.getLibro());
						}
				}
				else if(e.getSource().equals(btEliminar)){
						if(tfId.getText().equals("")){
							op.showMessageDialog(p,"Para ejecutar la consutla debe rellenar: ID","INFORMACI�N",JOptionPane.INFORMATION_MESSAGE);
						}else{
							gl.eliminarLibro(Integer.valueOf(tfId.getText()));
						}
					
				}else if(e.getSource().equals(btConsultarIsbn)){
					
						if(tfIsbn.getText().equals("")){
							op.showMessageDialog(p,"Para ejecutar la consutla debe rellenar: ISBN","INFORMACI�N",JOptionPane.INFORMATION_MESSAGE);
						}else{
							Tabla tab=new Tabla(gl.consultarISBN(tfIsbn.getText()));
							tab.getTabla().setBounds(10,500,1000,400);
							p.add(tab.getTabla(),0);
						}
				}else if(e.getSource().equals(btConsultarTitulo)){
				
					if(tfTitulo.getText().equals("")){
						op.showMessageDialog(p,"Para ejecutar la consutla debe rellenar: T�TULO","INFORMACI�N",JOptionPane.INFORMATION_MESSAGE);
					}else{
						Tabla tab=new Tabla(gl.consultarTitulo(tfTitulo.getText()));
						tab.getTabla().setBounds(10,500,1000,400);
						p.add(tab.getTabla(),0);
					}
				
				}else if(e.getSource().equals(btListar)){
						Tabla tab=new Tabla(gl.listarTodo());
						tab.getTabla().setBounds(10,500,1000,400);
						p.add(tab.getTabla(),0);
				
				
				}else if(e.getSource().equals(btModificarPrecio)){
				if(tfPrecio.getText().equals("")||tfIsbn.getText().equals("")){
					op.showMessageDialog(p,"Para ejecutar la consutla debe rellenar: ISBN y PRECIO","INFORMACI�N",JOptionPane.INFORMATION_MESSAGE);
				}
					
					gl.modificarPrecio(tfIsbn.getText(), Double.valueOf(tfPrecio.getText()));
				}
				
			}		
		
	}

