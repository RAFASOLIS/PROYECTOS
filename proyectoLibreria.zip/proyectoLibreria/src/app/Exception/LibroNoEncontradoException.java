package app.Exception;



public class LibroNoEncontradoException extends Exception {


	public   LibroNoEncontradoException(){
		
	
		super("Exception: Libro no encontrado");
		
	}
	public String getMessage(){
		return "Se ha producido una excepci�n. Libro no encontrado";
	}
}
